# msdc_v2.0

The official MSDC Inc (Pty) Ltd website rebuilt using Node.js in preparation for converting it into a SPA using React
